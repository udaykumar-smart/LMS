import axios from "axios";
//import Axios from 'axios';
export default () => {
  const baseURL = 'http://localhost:4040';
  let headers = {};

  // function out(){
  //   localStorage.removeItem()
  //window.localStorage.removeItem("token");
  // }
  // onclick=
//  window.localStorage.clear(); //clear all localstorage
  //window.localStorage.removeItem("token"); //remove one item

  if (localStorage.token) {
    headers.Authorization = `Bearer ${localStorage.token}`;
    
  }
  
  const axiosInstance = axios.create({
    baseURL: baseURL,
    headers,
  });

  axiosInstance.interceptors.response.use(
    (response) =>
      new Promise((resolve, reject) => {
        resolve(response);
      }),
    (error) => {
      if (!error.response) {
        return new Promise((resolve, reject) => {
          reject(error);
        });
      }

      if (error.response.status === 403) {
        localStorage.removeItem("token");
        // Unauth logic
        // redirect to login
      } else {
        return new Promise((resolve, reject) => {
            this.props.history.push('/AdminLogin');
          reject(error);
        });
      }
    }
  );

  return axiosInstance;
};