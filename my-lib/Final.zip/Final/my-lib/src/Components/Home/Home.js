import React from 'react'
import './Home.css'

import {Link} from 'react-router-dom' 
import HomeNavbar from '../../Navbar/HomeNavbar'



export default function Home() {
    return (
        <React.Fragment>
             {/* navbar code */}
            <div>
                <HomeNavbar/>
            </div>
         {/* body part  */}
        <div>
            
            <h1 id="home">Welcome to My Library</h1>
            <p id="hpara">Learning Management System (LMS) is a software application for the administration, documentation, tracking and e-learning.
            <p>It contains work like the number of available books in the library, the number of books are issued or returning or renewing a book or late fine charge record, etc. Library Management Systems is software that helps to maintain a database that is useful to enter new books and record books borrowed by the members, with the respective submission dates. Moreover, it also reduces the manual record burden of the librarian.</p>
            <p>It contains work like the number of available books in the library, the number of books are issued or returning or renewing a book or late fine charge record, etc. Library Management Systems is software that helps to maintain a database that is useful to enter new books and record books borrowed by the members, with the respective submission dates. Moreover, it also reduces the manual record burden of the librarian.</p>
            <p>It contains work like the number of available books in the library, the number of books are issued or returning or renewing a book or late fine charge record, etc. Library Management Systems is software that helps to maintain a database that is useful to enter new books and record books borrowed by the members, with the respective submission dates. Moreover, it also reduces the manual record burden of the librarian.</p>
                    
                </p>
           
            <div className="card" style={{width: "35rem"}}>
                <img src="https://th.bing.com/th/id/OIP.s3IuR3Ew4qEhPZyRrqhyggHaE8?pid=Api&rs=1" class="card-img-top" alt="..."/>
                <div class="card-body">
                <p style={{color:"crimson"}} class="card-text"><b></b><br/>Engineering Library</p>
            </div>
            </div>
            <div className="card" style={{width: "35rem"}}>
                <img src="https://th.bing.com/th/id/OIP.goP5ehAuHM40TgctshvAKQHaE7?pid=Api&rs=1" class="card-img-top" alt="..."/>
                <div class="card-body">
                <p style={{color:"darkblue"}} class="card-text"><b></b><br/>Business Library</p>
            </div>
            </div>
            
        </div>     

       </React.Fragment>
    )
}

 {/* <div>
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                    <a class="navbar-brand" href="#">MY Library</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Admin</a>
                            <i className="far fa-user-shield-alt"></i>
                            
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">User</a>
                            <i className="far fa-user-alt"></i>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Sections
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="#">Section1</a>
                            <a class="dropdown-item" href="#">Section2</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#">Other Section need to added</a>
                            </div>
                        </li>
                        {/* <li class="nav-item">
                            <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
                        </li>
                        </ul>
                        <form class="form-inline my-2 my-lg-0">
                        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"></input>
                        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Book Search</button>
                        </form>
                    </div>
                </nav>
        </div> *





         {/* <nav class="navbar navbar-light bg-info">
                <span class="navbar-brand mb-0 h1">My Library</span>
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item1 active">
                        <Link class="nav-link" to="login">Login<span class="sr-only">(current)</span></Link>
                    </li>
                </ul>
            </nav> */}