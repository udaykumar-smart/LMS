//import Axios from 'axios';
import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import UserNavbar from '../../../Navbar/UserNavbar';
import axiosInstance from '../../../Inter/Interceptor';
import jwtDecode from "jwt-decode";

const tab = {
    backgroundColor:"Crimson",
    marginTop:"10px"
}

export default class ShowBooks extends Component {

    constructor(props) {
        super(props);
        this.state = { booksCollection: [] ,books:[], booksCount:0} ;
        // this.state = {books:[]};
        // this.state={booksCount:0};
        this.deleteBook = this.deleteBook.bind(this);
    }
    login() 
    {
        //console.log("ok");
        axiosInstance().post('/users/login',{
          email: this.state.email,
          password:this.state.password
        })
            .then(res => {
              //console.log("success");
                if(res.data.token){
                 // localStorage.setItem("token",res.data.token);
                 // window.location.href='http://localhost:3000/BookBorrow';
                 //this.props.history.push('/BookBorrow');
                }
               
            })
            .catch(function (error) {
              //console.log("failed");
              alert(" Failed ,Invalid Login, Please try again.");
                console.log(error);
            })
      };
      
    deleteBook = (book_id) => {
        if (window.confirm('Are you sure to delete this record?')) {
            axiosInstance().delete('/book/'+ book_id)
        .then((res) => {
            console.log('Book successfully deleted!')
            alert('Deleted succesfully')
            this.setState({
                booksCollection: this.state.booksCollection.filter( remove => remove.book_id !== book_id)
            })
        }).catch((error) => {
            console.log(error)
        })
    }}
    componentDidMount() {
        //console.log("Component Mounted");
        axiosInstance().get('/book/allBooks')
            .then(res => {
               // console.log("res",res.data);
                this.setState({ booksCollection: res.data.book_info });
            })
            .catch(function (error) {
                console.log(error);
            })
    }
    bookSelected(e,id){
        //console.log('Event', e);
        if(this.state.booksCount >= 3 && e){
            alert("Maximum Limit Exceeded");
        }
        else if(e){
            this.state.books.push(id);
            //console.log(id);
            const book_id=id;
           // const a[...x]=id;
            console.log(book_id);
            this.state.booksCount++;
            this.setState(this.state);
        }
        else{
            this.state.booksCount--;
            this.state.books.filter(x=> x!=id);
            this.setState(this.state);
            e=false;
        }
    }

    
    render() {
    return (
        <>
        <div ><UserNavbar/></div>
        
       
             <div className="row p-10">
                    <div className="col-10">
                        <div className="row">
                             <div className="col-2" >
                                    <div className="col-1">
                                     {/* side bar */}
                                    <div className="col-10" style={{marginTop:"100px", marginLeft:"80px"}}>
                                        <form style={{marginTop:"15px", width:"180px"}}  >
                                            <div class="form-row ">
                                            <label for="exampleFormControlSelect1">Borrower Name</label>
                                            <select class="form-control" id="exampleFormControlSelect1">
                                                <option>1</option>
                                            </select>
                                            </div>
                                        
                                            <div class="form-row ">
                                            <label for="exampleFormControlInput1">Due Date</label>
                                            <input type="date" class="form-control" id="exampleFormControlInput1" />
                                            </div>
                                            <div class="form-row " style={{marginTop:"10px"}}>
                                            <button type="submit" class="btn btn-success">Borrow</button>
                                            </div>
                                        </form>
                                    </div>
            </div>
                            </div> 
                            <div className="col-10" >
                            <h2 className="text-center text-dark" style={{marginLeft:"250px", marginTop:"50px"}}>Request The Books</h2>
                            
                            
                            <table class="table table-hover table-bordered table-info table-condensed mt-3" style={{marginLeft:"150px"}}>
                                    <thead class="thead-info table-hover" style={{textAlign:"center"}}>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">BOOK TITLE</th>
                                        <th scope="col">CATEGORY</th>
                                        <th scope="col">AUTHOR</th>
                                        <th scope="col">PUBLISHER NAME</th>
                                        <th scope="col">STATUS</th>
                                        <th scope="col">ACTION</th>
						            </tr>
                                    </thead>
                                    <tbody style={{textAlign:"center"}} >
                                   
                                        {this.state.booksCollection?.map(book => (
                                            <tr>
                                                <td>
                                                    {book.book_id}  
                                                </td>
                                                 <td>
                                                    {book.book_title}
                                                </td> 
                                                <td>
                                                    {book.category_id}
                                                </td>
                                                <td>
                                                    {book.author}
                                                </td>
                                              
                                                <td>
                                                    {book.publisher_name}
                                                </td>
                                               
                                                <td>
                                                    {book.status}
                                                </td>
                                                <td>
												<input type="checkbox" onChange={e=>this.bookSelected(e.target.value, book.book_id)}/>
                                                </td>
                                                {/* <td >
                                                <Link to={{pathname:"/EditBooks",query:book.book_id}} state={book.book_id}><button size="sm" style={{ cursor:"pointer", width:"100px", margin:"5px 0"}} className="btn text-danger fa fa-pencil"></button></Link>
                                                <button size="sm" onClick={() => this.deleteBook(book.book_id)} style={{ cursor:"pointer", width:"100px"}}className="btn text-danger fa fa-trash"></button>
                                                </td> */}
                                            </tr>
                                        ))}

                                    </tbody>
                            </table>

                            </div>
                        </div>
                    </div>
              </div>          
        {/* </div> */}
        </>
    )
}
}

// <h1>Using Form</h1>
// <form method="post" name="form_name" id="form_name">
// 	<input type="checkbox" name="check[]" value="CheckBox 1"/>
// 	<input type="checkbox" name="check[]" value="CheckBox 2"/>
// 	<input type="checkbox" name="check[]" value="CheckBox 3"/>
// </form>
// <script type="text/javascript">checkBoxLimit()</script>

// function checkBoxLimit() {
// 	var checkBoxGroup = document.forms['form_name']['check[]'];			
// 	var limit = 3;
// 	for (var i = 0; i < checkBoxGroup.length; i++) {
// 		checkBoxGroup[i].onclick = function() {
// 			var checkedcount = 0;
// 			for (var i = 0; i < checkBoxGroup.length; i++) {
// 				checkedcount += (checkBoxGroup[i].checked) ? 1 : 0;
// 			}
// 			if (checkedcount > limit) {
// 				console.log("You can select maximum of " + limit + " checkboxes.");
// 				alert("You can select maximum of " + limit + " checkboxes.");						
// 				this.checked = false;
// 			}
// 		}
// 	}
// }



// <div class="box">
//     <h3>Java</h3>
// </div>
// <div class="box">
//     <button  type="button" class="btn btn-light btn-light btn-outline-dark" onclick="addone4()" value="Increment Value" id="value">Click Me</button>
// </div>
// <div class="box">
//     <h1><span id="thisone4">0</span></h1>
// </div>

// function addone4(){
//     var res4=document.getElementById('thisone4').innerHTML
//     res4++;
//     document.getElementById('thisone4').innerHTML=res4;
// }
// <div class="box">
//     <h3 style="color: white;">Vote</h3>
// </div>

// import React from 'react';
// import {Link} from 'react-router-dom'
// import UserNavbar from '../../../Navbar/UserNavbar';


// export default function bookBorrow() 
// {
//     return (
//         <React.Fragment>
// 			<div>
// 				<UserNavbar/>
// 			</div>
//             <div>
//         <table class="table table-hover">
//         <thead class="table table-hover"> 
//         <tr>
//             <th scope="col">ACC NO.</th>
//             <th scope="col">BOOK TITLE</th>
//             <th scope="col">CATEGORY</th>
//             <th scope="col">AUTHOR</th>
//             <th scope="col">PUBLISHER NAME</th>
//             <th scope="col">STATUS</th>
//             <th scope="col">ADD</th>
//         </tr>

//         </thead>
// 	<tbody>  
// 		<tr>
//             <th scope="row">15</th>
// 			<td>Natural Resources</td>
// 			<td>Microbiology</td>
// 			<td>Robin Kerrod</td>
// 			<td>Marshall</td>
// 			<td>New</td>
// 			<td>
// 			<input type="checkbox" id="add" name="add" value="add"/>
// 			</td>
// 		</tr>
// 		<tr>
//             <th scope="row">16</th>
// 			<td>Encyclopedia Americana</td>
// 			<td>Encyclopedia</td>
// 			<td>Grolier</td>
// 			<td>Grolier Incorporation</td>
// 			<td>Archive</td>
// 			<td>
// 			<input type="checkbox" id="add" name="add" value="add"/>
// 			</td>
// 		</tr>
// 		<tr>
//             <th scope="row">17</th>
// 			<td>Algebra 1</td>
// 			<td>Mathematics</td>
// 			<td>Carolyn Bradshaw</td>
// 			<td>Pearson Education Inc</td>
// 			<td>Damage</td>
//             <td>
//             <input type="checkbox" id="add" name="add" value="add"/>
//             </td>
// 		</tr>
// 		<tr>
//             <th scope="row">18</th>
// 			<td>Beloved a Novel</td>
// 			<td></td>
// 			<td>Toni Morrison</td>
// 			<td>Knoff Inc</td>
// 			<td>Old</td>
// 			<td>
//             <input type="checkbox" id="add" name="add" value="add"/>
// 			</td>
// 		</tr>
		
// 	</tbody>
// </table>
     
//             </div>
//         </React.Fragment>
        
//     )
// }
// // import React from 'react';
// // import ShowBooks from '../../Admin/ShowBooks/ShowBooks';


// // function BookShow(){
// //     return(
// //         <ShowBooks/>
// //     )
// // }

// // export default BookShow;