import React from 'react';


import {Link} from 'react-router-dom'
import UserNavbar from '../../../Navbar/UserNavbar';


export default function BookSearch() 
{
    return (
        <>
			<div>
				<UserNavbar/>
			</div>
     
       {/* <div>
        <form >
            <div class="form-row col-md-2 mb-3" >
              <label for="exampleFormControlSelect1">Borrower Name</label>
              <select class="form-control" id="exampleFormControlSelect1">
                <option>1</option>
              </select>
            </div>
        
            <div class="form-row col-md-2 mb-3">
              <label for="exampleFormControlInput1">Due Date</label>
              <input type="date" class="form-control" id="exampleFormControlInput1" />
            </div>
            <div class="form-row col-md-2 mb-3">
              <button type="submit" class="btn btn-success">Borrow</button>
            </div>
        </form>
      </div>  */}


           

                       
        </>
        
    )
}






