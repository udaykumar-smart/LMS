import React from 'react';
import './Contact.css'
import {Link} from 'react-router-dom';
import HomeNavbar from '../../Navbar/HomeNavbar'


export default function Contact(){
    return (
        <React.Fragment>
        {/* navbar code */}
            <div>
                <HomeNavbar/>
            </div>
     
       

        {/* body-part */}
        <div>
             <h1 className="contact" >Contact Us</h1>
             <div className="card" style={{width: "55rem", marginLeft:"500px", 
                    border:"2px solid skyblue",padding:"10px",}}>
                        <img src="https://www.anandgroupindia.com/wp-content/uploads/2019/05/contactus.jpg" class="card-img-top" alt="..."/>
                        <div class="card-body">
                            <p style={{color:"black"}} class="card-text">Name: Uday <br/> Contact:(+91)-9676326184 <br/> Website: www.library.com
                            <br/>Email:Contactus@mylibrary.com</p>
                        </div>
                    </div>
        </div>
        </React.Fragment>
    )
}

