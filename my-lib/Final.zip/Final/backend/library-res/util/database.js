const { Client } = require('pg');

const client = new Client({
    host: 'library-db.c6d2qq9110go.us-east-1.rds.amazonaws.com',
    port: 5432,
    password: '7013019722',
    database: 'library',
    user: 'postgres'
});

client.connect().then(success => {
    console.log('Database connected successfully');
}).catch(err => {
    console.log('DB Error', err);
});

module.exports = client;